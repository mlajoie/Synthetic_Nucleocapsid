#CompA_Oligos_Final.txt


from __future__ import division
import optparse
import re
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from collections import Counter

import gzip
import math
from sys import exit

parser = optparse.OptionParser()
(options,args) = parser.parse_args()

#print args[0][-3:]



readsFile1 = open(args[0]).readlines()
readsFile2 = open(args[1]).readlines()

oligosFile = open(args[2]).readlines()

outfile = open(args[3],'w')

aa_list = 'A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y', '*'

def make_SSM_dict( readfile , oligofile , readoffset , oligo_offset):
	print 'start function'
	aa_list = 'A', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y', '*'
	aa_dict = {}
	aa_pos_dict = {}
	i = 3
	while i in range(3,160):
		#aa_pos_dict[i] = 0
		#print aa_pos_dict[i]
		aa_pos_dict[i] = {'A':0, 'C':0, 'D':0, 'E':0, 'F':0, 'G':0, 'H':0, 'I':0, 'K':0, 'L':0, 'M':0, 'N':0, 'P':0, 'Q':0, 'R':0, 'S':0, 'T':0, 'V':0, 'W':0, 'Y':0, '*':0}
		#print aa_dict
		#aa_pos_dict[i] = aa_dict
		#print aa_pos_dict
		i = i + 3
	#aa_pos_dict[3]['W'] = 232
	#print aa_pos_dict

	position = 0
	aa = 0
	count_good_seq = 0

	for line in oligosFile:
		aa = aa + 1
		#print aa
		oligo_seq = line[(oligo_offset+position):(oligo_offset+position+9)]
		#print 'oli'
		#print oligo_seq
		for line in readfile:
			#print line
			#print 'line'
			#print line[ (5+position) : (5 + position + 9)]
			#print 'oligo'
			#print oligo_seq
			#print 'seq'
			#print line[(position + readoffset) : (position + 9  + readoffset)]
			#print 'oli'
			#print oligo_seq
			if oligo_seq == line[(position + readoffset) : (position + 9  + readoffset)]:
				#count_good_seq = count_good_seq + 1
				
				temp_aa = str(Seq((line[(position+3+ readoffset):(position + readoffset+ 6)]),IUPAC.unambiguous_dna).translate())
				#print temp_aa
				if str(temp_aa) in aa_list:
					#print 'in list' + temp_aa
					aa_pos_dict[(((position)+3))][temp_aa] = aa_pos_dict[(((position)+3))][temp_aa] + 1
					#print aa_pos_dict[(((position)+3))][temp_aa]
		if aa == 20:
			print 'aa' + str(aa)
			position = position + 3
			aa = 0
			#print 'pos' + str(position)
		#print count_good_seq
		if position == 159:
			break
			
		
	return aa_pos_dict
	
aa_dict_select = make_SSM_dict( readsFile1 , oligosFile , 159, 22 )
aa_dict_cells = make_SSM_dict( readsFile2 , oligosFile , 159, 22 )

print aa_dict_select
print aa_dict_cells


Select_total_counts = 0
for line in readsFile1:	
	Select_total_counts = Select_total_counts + 1
print Select_total_counts
	
Input_total_counts = 0	
for line in readsFile2:	
	Input_total_counts = Input_total_counts + 1	
print Input_total_counts

i = 3	
pos_count_select = 0
outfile.write('\n')
outfile.write('\t'+',')
while i <= 159:
		for item in aa_list:
			#print 'wroking'
			pos_count_select = pos_count_select + aa_dict_select[i][item]
		outfile.write(str(pos_count_select) + ', ')
		i = i + 3
print pos_count_select
pos_count_input = 0	
i = 3	
outfile.write('\n')
outfile.write('\t'+',')
while i <= 159:
		for item in aa_list:
			#print 'wroking'
			pos_count_input = pos_count_input + aa_dict_cells[i][item]
		outfile.write(str(pos_count_input) + ', ')
		i = i + 3
print pos_count_input

for item in aa_list:
	outfile.write('\n' + item + ', ')
	i = 3
	#print 'asdasdarasdfaertgfaergaerfgd'
	while i <= 159:
		print 'i= ' + str(i)
		print aa_dict_select[i]
		#outfile.write(str(i) + ', ')
		print str(i) + item + 'sel= ' + str(aa_dict_select[i][item]) + 'cell= ' + str(aa_dict_cells[i][item])
		if aa_dict_cells[i][item] >= 10 and aa_dict_select[i][item] >= 1:
			enrich = str(math.log10((int(aa_dict_select[i][item])/pos_count_select) / (int(aa_dict_cells[i][item])/pos_count_input)))
			print enrich
			outfile.write(enrich + ', ')
		elif aa_dict_cells[i][item] >= 10 and aa_dict_select[i][item] == 0:
			enrich = str(math.log10((0.5/pos_count_select) / (int(aa_dict_cells[i][item])/pos_count_input)))
			print enrich
			outfile.write(enrich + ', ')
		else:
			outfile.write('NA' + ', ')
		i = i + 3

			
	
i = 3	
pos_count_select = 0
outfile.write('\n')
outfile.write('\t'+',')
while i <= 159:
		for item in aa_list:
			#print 'wroking'
			pos_count_select = pos_count_select + aa_dict_select[i][item]
		outfile.write(str(pos_count_select) + ', ')
		pos_count_select = 0
		i = i + 3
pos_count_input = 0	
i = 3	
outfile.write('\n')
outfile.write('\t'+',')
while i <= 159:
		for item in aa_list:
			#print 'wroking'
			pos_count_input = pos_count_input + aa_dict_cells[i][item]
		outfile.write(str(pos_count_input) + ', ')
		pos_count_input = 0
		i = i + 3
			

