Readme

These are custom scripts for analyzing barcoded deep mutational scanning data. There is a separate script for each oligo window with its own internal offsets to match barcoded mutagenic oligonucleotides to mutations in recovered sequences.

This assumes that you have already aligned Fwd and Rev reads 

The command line is as follows:
(X= oligo pool)
python AnalyzeBarcodeSSM_X.py {selected_sample_file_name} {naive_sample_file_name} oligosX.txt {desired_output_name}.csv